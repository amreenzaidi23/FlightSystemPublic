package amreen.zaidi.ek.test.controller;

import java.util.List;

import amreen.zaidi.ek.test.model.Airport;
import amreen.zaidi.ek.test.model.Flight;
import amreen.zaidi.ek.test.service.AirportService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


@RestController
@RequestMapping("/airport")
public class AirportController {
    @Autowired
    private AirportService airportService;

    @GetMapping("/say")
    public String sayHello() {
        return "Hello Spring boot";
    }

    @GetMapping
    public List<Airport> getAll() {
        return airportService.getAll();
    }

    @PostMapping
    public ResponseEntity<?> save(@RequestBody Airport airport) {
        Airport savedAirport = airportService.save(airport);
        return ResponseEntity.ok().body(savedAirport);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> delete(@PathVariable int id) {
        airportService.delete(id);
        return ResponseEntity.ok().body("Deleted successfully...!");
    }
    @PutMapping("/{id}")
    public ResponseEntity<?> update(@PathVariable int id, @RequestBody Airport airport) {
        Airport updatedAirport = airportService.update(id, airport);
        return ResponseEntity.ok().body(updatedAirport);
    }

}
