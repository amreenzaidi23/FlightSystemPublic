package amreen.zaidi.ek.test.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Entity;
import java.io.Serializable;
@Data
@NoArgsConstructor
@Builder

public class FlightConnection implements Serializable {
    public FlightConnection(String onwardFltNo, String onwardDepArpt, String onwardArrArpt, String onwardDepTime, String onwardArrTime, String connFltNo, String connDepArpt, String connArrArpt, String connDepTime, String connArrTime,String fromAirCo,String connAirCo,String toAirCo){
        this.onwardFltNo=onwardFltNo;
        this.onwardDepArpt=onwardDepArpt;
        this.onwardArrArpt=onwardArrArpt;
        this.onwardDepTime=onwardDepTime;
        this.onwardArrTime=onwardArrTime;
        this.connFltNo=connFltNo;
        this.connDepArpt=connDepArpt;
        this.connArrArpt=connArrArpt;
        this.connDepTime=connDepTime;
        this.connArrTime=connArrTime;
        this.fromAirCo=fromAirCo;
        this.connAirCo=connAirCo;
        this.toAirCo=toAirCo;

    }
    private String onwardFltNo;
    private String onwardDepArpt;
    private String onwardArrArpt;
    private String onwardDepTime;
    private String onwardArrTime;
    private String connFltNo;
    private String connDepArpt;
    private String connArrArpt;
    private String connDepTime;
    private String connArrTime;
    private String fromAirCo;
    private String connAirCo;
    private String toAirCo;

}
