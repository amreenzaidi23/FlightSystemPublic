package amreen.zaidi.ek.test.service;

import amreen.zaidi.ek.test.model.Flight;
import amreen.zaidi.ek.test.model.FlightConnection;

import java.util.List;

public interface FlightService {

    List<Flight> getAll();
    List<FlightConnection> find(String from , String to);
    Flight save(Flight flight);
    void delete(int id);
    Flight update(int id , Flight flight);
}
