package amreen.zaidi.ek.test.service.impl;

import amreen.zaidi.ek.test.model.Airport;
import amreen.zaidi.ek.test.repository.AirportRepository;
import amreen.zaidi.ek.test.service.AirportService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.webjars.NotFoundException;

import java.util.List;

@Service
public class AirportServiceImpl implements AirportService{
    @Autowired
    private AirportRepository repository;

    @Override
    public List<Airport> getAll() {
        return repository.findAll();
    }
    @Override
    public Airport save(Airport airport) {
        return repository.save(airport);
    }
    @Override
    public void delete(int id) {
        repository.findById(id).ifPresent(Airport -> repository.delete(Airport));
    }
    @Override
    public Airport update(int id, Airport airport) {
        repository.findById(id).orElseThrow(() -> new NotFoundException("** Airport not found for id :: " + id));

        airport.setId(id);
        return repository.save(airport);
    }
}
