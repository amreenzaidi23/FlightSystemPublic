package amreen.zaidi.ek.test.service;

import java.util.List;

import amreen.zaidi.ek.test.model.Airport;

public interface AirportService {
    List<Airport> getAll();
    Airport save(Airport airport);
    void delete(int id);
    Airport update(int id, Airport airport);

}
