package amreen.zaidi.ek.test.utils;

import java.util.Arrays;
import java.util.List;
import java.util.function.Supplier;

import amreen.zaidi.ek.test.model.Airport;
import amreen.zaidi.ek.test.model.Flight;


public class HelperUtil {

    private HelperUtil() {
    }


    public static Supplier<List<Airport>> airpotSupplier = () ->
			Arrays.asList(
					Airport.builder().arptCd("BOM").arptName("Chhatrapati Shivaji Maharaj International").cityName("Mumbai").coordinates("19.05 72.52").build(),
					Airport.builder().arptCd("DXB").arptName("Dubai International").cityName("Dubai").coordinates("25.15 55.21").build(),
					Airport.builder().arptCd("JFK").arptName("Jhon F Kennedy Airport International").cityName("New York").coordinates("40.38 -73.46").build()
			);


	public static Supplier<List<Flight>> flightSupplier = () ->
			Arrays.asList(
					Flight.builder().onwardFltNo("EK 500").onwardDepArpt("BOM").onwardArrArpt("DXB").onwardDepTime("1").onwardArrTime("3").build(),
					Flight.builder().onwardFltNo("EK 200").onwardDepArpt("DXB").onwardArrArpt("JFK").onwardDepTime("5").onwardArrTime("9").build(),
					Flight.builder().onwardFltNo("EK 300").onwardDepArpt("DXB").onwardArrArpt("JFK").onwardDepTime("1").onwardArrTime("3").build(),
					Flight.builder().onwardFltNo("EK 300").onwardDepArpt("DEL").onwardArrArpt("DXB").onwardDepTime("9").onwardArrTime("11").build()

					);



}
