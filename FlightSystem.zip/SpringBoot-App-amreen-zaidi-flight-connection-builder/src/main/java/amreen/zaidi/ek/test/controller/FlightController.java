package amreen.zaidi.ek.test.controller;

import amreen.zaidi.ek.test.model.Airport;
import amreen.zaidi.ek.test.model.Flight;
import amreen.zaidi.ek.test.model.FlightConnection;
import amreen.zaidi.ek.test.service.FlightService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/flight")
public class FlightController {

    @Autowired
    private FlightService flightService;


    @GetMapping
    public List<Flight> getAll() {
        return flightService.getAll();
    }

    @GetMapping("/{from}/{to}")
    public ResponseEntity<?> find(@PathVariable String from, @PathVariable String to) {
        List<FlightConnection>  flights = flightService.find(from,to);
        return ResponseEntity.ok().body(flights);
    }

    @PostMapping
    public ResponseEntity<?> save(@RequestBody Flight flight) {
        Flight savedFlight = flightService.save(flight);
        return ResponseEntity.ok().body(savedFlight);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> delete(@PathVariable int id) {
        flightService.delete(id);
        return ResponseEntity.ok().body("Deleted successfully...!");
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> update(@PathVariable int id, @RequestBody Flight flight) {
        Flight updatedFlight = flightService.update(id, flight);
        return ResponseEntity.ok().body(updatedFlight);
    }

}
