package amreen.zaidi.ek.test.model;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Entity
@Table
public class Flight implements Serializable {
    @Id
    @GeneratedValue
    private int id;
    private String onwardFltNo;
    private String onwardDepArpt;
    private String onwardArrArpt;
    private String onwardDepTime;
    private String onwardArrTime;

    public void setId(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public String getOnwardFltNo() {
        return onwardFltNo;
    }

    public String getOnwardDepArpt() {
        return onwardDepArpt;
    }

    public String getOnwardArrArpt() {
        return onwardArrArpt;
    }

    public String getOnwardDepTime() {
        return onwardDepTime;
    }

    public String getOnwardArrTime() {
        return onwardArrTime;
    }
}
