package amreen.zaidi.ek.test;

import amreen.zaidi.ek.test.model.Flight;
import amreen.zaidi.ek.test.model.Airport;


import amreen.zaidi.ek.test.repository.AirportRepository;
import amreen.zaidi.ek.test.repository.FlightRepository;
import amreen.zaidi.ek.test.utils.HelperUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.List;


@Slf4j
@SpringBootApplication
@EnableJpaRepositories
public class FlightConnectionBuilderApplication {

	public static void main(String[] args) {
		SpringApplication.run(FlightConnectionBuilderApplication.class, args);
	}




	@Autowired
	private AirportRepository airportRepository;

	@Autowired
	private FlightRepository flightRepository;

	@Bean
	CommandLineRunner runner() {
		return args -> {
			List<Airport> airports = airportRepository.findAll();
			if (airports.isEmpty()) {
				log.info("******* Inserting airpot to DB *******");
				airportRepository.saveAll(HelperUtil.airpotSupplier.get());
			} else {
				log.info("******* airport stored in DB Size :: {}", airports.size());
				log.info("******* airport stored in DB :: {}", airports);
			}

			List<Flight> flights = flightRepository.findAll();
			if (airports.isEmpty()) {
				log.info("******* Inserting flight to DB *******");
				flightRepository.saveAll(HelperUtil.flightSupplier.get());
			} else {
				log.info("******* flight stored in DB Size :: {}", flights.size());
				log.info("******* flight stored in DB :: {}", flights);
			}

		};
	}

}
