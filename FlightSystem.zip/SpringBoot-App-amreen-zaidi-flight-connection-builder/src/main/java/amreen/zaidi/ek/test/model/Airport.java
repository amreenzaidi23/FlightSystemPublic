package amreen.zaidi.ek.test.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Entity
@Table
public class Airport implements Serializable {
    @Id
    @GeneratedValue
    private int id;

    private String arptCd;
    private String arptName;
    private String cityName;
    private String coordinates;

    public void setId(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public String getArptCd() {
        return arptCd;
    }

    public String getArptName() {
        return arptName;
    }

    public String getCityName() {
        return cityName;
    }

    public String getCoordinates() {
        return coordinates;
    }
}
