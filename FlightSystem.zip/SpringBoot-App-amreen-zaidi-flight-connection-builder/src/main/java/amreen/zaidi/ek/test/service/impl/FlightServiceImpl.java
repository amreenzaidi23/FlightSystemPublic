package amreen.zaidi.ek.test.service.impl;

import amreen.zaidi.ek.test.model.Airport;
import amreen.zaidi.ek.test.model.Flight;
import amreen.zaidi.ek.test.model.FlightConnection;
import amreen.zaidi.ek.test.repository.FlightRepository;

import amreen.zaidi.ek.test.service.AirportService;
import amreen.zaidi.ek.test.service.FlightService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.webjars.NotFoundException;

import java.util.ArrayList;
import java.util.List;
@Service
public class FlightServiceImpl implements FlightService {
    @Autowired
    private FlightRepository repository;
    @Autowired
    private AirportService airportService;

    @Override
    public List<Flight> getAll() {
        return repository.findAll();
    }

    @Override
    public Flight save(Flight flight) {
        return repository.save(flight);
    }
    @Override
    public void delete(int id) {
        repository.findById(id).ifPresent(Flight -> repository.delete(Flight));
    }

    @Override
    public Flight update(int id, Flight flight) {
        repository.findById(id).orElseThrow(() -> new NotFoundException("** Flight not found for id :: " + id));

        flight.setId(id);
        return repository.save(flight);
    }

    @Override
    public List<FlightConnection> find(String from, String to) {
        List<Flight> fromFlights = new ArrayList<>();
        List<Flight> toFlights = new ArrayList<>();
        List<FlightConnection> flightConns=new ArrayList<>();
        List<Flight> list = repository.findAll();

        for (Flight flight : list) {
            if (flight.getOnwardDepArpt().equalsIgnoreCase(from) )
                fromFlights.add(flight);
            if(flight.getOnwardArrArpt().equalsIgnoreCase(to))
                toFlights.add(flight);
        }
        List<FlightConnection> flightConn=getFlightConn(fromFlights,toFlights);

        return flightConn;
    }


    private List<FlightConnection> getFlightConn(List<Flight> fromFlight,List<Flight> toFlight){
        List<FlightConnection> flightConns=new ArrayList<>();
        List<Airport> airports=airportService.getAll();

        for(Flight from:fromFlight){
            for(Flight to:toFlight){
                int fromTime= Integer.parseInt(from.getOnwardArrTime());
                int toTime=Integer.parseInt(to.getOnwardDepTime());
                int diff=getDiff(fromTime,toTime);
                if(fromTime<toTime && (diff>=2 && diff<=8)) {
                    String airportCoordinates= getLangForAirport(from.getOnwardDepArpt(),from.getOnwardArrArpt(),to.getOnwardArrArpt(),airports);
                    String fromAirCoo=airportCoordinates.split("#")[0];
                    String connAirCoo=airportCoordinates.split("#")[1];

                    String toAirCoo=airportCoordinates.split("#")[2];
                    flightConns.add(new FlightConnection(from.getOnwardFltNo(), from.getOnwardDepArpt(), from.getOnwardArrArpt(), from.getOnwardDepTime(), from.getOnwardArrTime(), to.getOnwardFltNo(), to.getOnwardDepArpt(), to.getOnwardArrArpt(), to.getOnwardDepTime(), to.getOnwardArrTime(),fromAirCoo,connAirCoo,toAirCoo));

                }
            }

        }

        return flightConns;
    }
    private String getLangForAirport(String fromAirportCode,String connAirCode,String toAirportCode,List<Airport> airports){
        String fromAirCoordinates="";
        String connAirCoordinates="";
        String toAirCoordinates="";
        for(Airport airport:airports){
            if(airport.getArptCd().equalsIgnoreCase(fromAirportCode)){
                fromAirCoordinates=airport.getCoordinates();
            }
            if(airport.getArptCd().equalsIgnoreCase(connAirCode)){
                connAirCoordinates=airport.getCoordinates();
            }
            if(airport.getArptCd().equalsIgnoreCase(toAirportCode)){
                toAirCoordinates=airport.getCoordinates();
            }

        }
        return fromAirCoordinates+"#"+connAirCoordinates+"#"+toAirCoordinates;
    }
    private int getDiff(int f,int t){
        return (t-f);
    }
}
