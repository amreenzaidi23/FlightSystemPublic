package amreen.zaidi.test;
import amreen.zaidi.ek.test.repository.AirportRepository;
import amreen.zaidi.ek.test.repository.FlightRepository;
import amreen.zaidi.ek.test.service.AirportService;
import amreen.zaidi.ek.test.service.FlightService;
import amreen.zaidi.ek.test.service.impl.AirportServiceImpl;
import amreen.zaidi.ek.test.service.impl.FlightServiceImpl;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class TestFlight {
    @Autowired
    private FlightRepository airportRepository;

    @Test
    public void testFlight() {

        FlightService obj = new FlightServiceImpl();
        assertEquals("Hello test", obj.getAll().get(0).toString());

    }
}
