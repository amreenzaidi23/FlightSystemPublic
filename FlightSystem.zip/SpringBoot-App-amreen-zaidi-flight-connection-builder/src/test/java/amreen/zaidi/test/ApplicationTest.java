package amreen.zaidi.test;
import amreen.zaidi.ek.test.FlightConnectionBuilderApplication;
import amreen.zaidi.ek.test.service.AirportService;
import amreen.zaidi.ek.test.service.impl.AirportServiceImpl;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.ApplicationContext;
import org.springframework.test.context.junit4.SpringRunner;
import static org.junit.jupiter.api.Assertions.assertTrue;

@SpringBootTest
public class ApplicationTest {



    @Test
    public void contextLoads() {
       // AirportService calculator = ac.getBean(AirportService.class);
        //assertTrue(calculator instanceof AirportServiceImpl);
        FlightConnectionBuilderApplication.main(new String[]{});
    }
}