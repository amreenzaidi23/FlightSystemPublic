package amreen.zaidi.test;
import amreen.zaidi.ek.test.model.Airport;
import amreen.zaidi.ek.test.repository.AirportRepository;
import amreen.zaidi.ek.test.service.AirportService;
import amreen.zaidi.ek.test.service.impl.AirportServiceImpl;
import org.junit.Before;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.hamcrest.core.StringContains.containsString;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
public class TestAirport {
    private AirportService airportService;

    @Before
    public void setup() {
        this.airportService = new AirportServiceImpl();
    }
    @Test
    public void testAirportCount() {
        assertEquals(3, airportService.getAll().size());

    }

    @Test
    public void testAirportCodeShouldBeThreeChar (){
        for(Airport airport:airportService.getAll()) {
            assertEquals(3, airport.getArptCd().length());
        }
    }


}
