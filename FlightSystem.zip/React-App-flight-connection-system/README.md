IDE to use:
### Visual Basic

Pre-requisite:
### Backend service should be up and running (SpringBoot project)

Installation
### 'npm install --save google-map-react'

In the project directory, you can run using:

### `npm start`

Application will appear on below url:
### http://localhost:3000/

