import React, { Component } from 'react';
import axios from "axios";
import './App.css';
import TableRow from "./component/TableRow";
import { Map, InfoWindow, Marker, GoogleApiWrapper } from 'google-maps-react';

let styles = {
  marginTop: "10px"
};

var l1 = "";
var lo1 = "";
var l2 = "";
var lo2 = "";
var l3 = "";
var lo3 = "";
class App extends Component {

  constructor(props) {
    super(props);
    this.state = { lat1: "", long1: "", lat2: "", long2: "", lat3: "", long3: "", value: "", items: "" };
    this.handleChange = this.handleChange.bind(this)
    this.handleSubmit = this.handleSubmit.bind(this)
  }

  handleSubmit(event) {
    const { from, to } = this.state
    event.preventDefault()
    axios
      .get(`http://localhost:8088/flight/${from}/${to}`)
      .then(response => {
        this.setState({ items: response.data });
      })
      .catch(function (error) {
        console.log(error);
      });


  }

  handleChange(event) {
    this.setState({
      // Computed property names
      // keys of the objects are computed dynamically
      [event.target.name]: event.target.value
    })
  }

  tabRow() {
    console.log(this.state.items);
    console.log(this.state.items instanceof Array);

    if (this.state.items instanceof Array) {
      return this.state.items.map(function (object, i) {
        console.log(i + "   " + object.fromAirCo.split(" ")[0])
        // const ob={object}
        l1 = object.fromAirCo.split(" ")[0];
        lo1 = object.fromAirCo.split(" ")[1];
        l2 = object.connAirCo.split(" ")[0];
        lo2 = object.connAirCo.split(" ")[1];
        l3 = object.toAirCo.split(" ")[0];
        lo3 = object.toAirCo.split(" ")[1];

        // console.log(i + "   " + l1)
        return <TableRow obj={object} key={i} />;
      });
    }
  }



  render() {
    const style = {
      width: '100%',
      height: '80%',
      position: 'center'
    }

    return (
      <div className="App" >
        <h2 id='title'>Flight Search System</h2>
        <form onSubmit={this.handleSubmit} style={styles}>
          <tr>
            <td> From Airport  </td>
            <td> <input name='from' placeholder="From airport..." value={this.state.from}
              onChange={this.handleChange} /></td>
          </tr>
          <tr>

            <td> To Airport </td>
            <td>  <input name='to' placeholder="To airport..." value={this.state.to}
              onChange={this.handleChange} /></td>

            <td> <input type="submit" value="Search" /></td>
          </tr>

        </form>


        <table className="table table-striped table-bordered" style={styles}>
          <thead>
            <tr>
              <td>Onward Flight</td>
              <td>Dep Airport</td>
              <td>Arrival Airport</td>
              <td>Dep Time</td>
              <td>Arr Time</td>
              <td>Connecting Flight</td>
              <td>Dep Airport</td>
              <td>Arrival Airport</td>
              <td>Dep Time</td>
              <td>Arr Time</td>
            </tr>
          </thead>
          <tbody>{this.tabRow()}</tbody>
        </table>

        <Map className="containerStyle" style={style}
          google={this.props.google} 
          zoom={2}
          onLoad={this.onGoogleMapLoad}
        >

          <Marker
            key={l1}
            position={{ lat: l1, lng: lo1 }}
          >
            <InfoWindow>
              <div>
                {l1}
              </div>
            </InfoWindow>
          </Marker>

          <Marker
            key={l2}
            position={{ lat: l2, lng: lo2 }}
          >
            <InfoWindow>
              <div>
                {l2}
              </div>
            </InfoWindow>
          </Marker>

         <Marker
            key={l3}
            position={{ lat: l3, lng: lo3 }}
          >
            <InfoWindow>
              <div>
                {l3}
              </div>
            </InfoWindow>
          </Marker> 
        </Map>
      </div>
    );
  }
}

export default GoogleApiWrapper({
  apiKey: ("AIzaSyCK9lRCs-XR_CCcqNhUjFjrVWOWC7ym9yQ")
})(App)