import React, { Component } from "react";
class TableRow extends Component {
  constructor(props) {
    super(props);
  }

  render() {
    return (
      <tr>
        <td>{this.props.obj.onwardFltNo}</td>
        <td>{this.props.obj.onwardDepArpt}</td>
        <td>{this.props.obj.onwardArrArpt}</td>
        <td>{this.props.obj.onwardDepTime}</td>
        <td>{this.props.obj.onwardArrTime}</td>
        <td>{this.props.obj.connFltNo}</td>
        <td>{this.props.obj.connDepArpt}</td>
        <td>{this.props.obj.connArrArpt}</td>
        <td>{this.props.obj.connDepTime}</td>
        <td>{this.props.obj.connArrTime}</td>
        
      </tr>
    );
  }
}

export default TableRow;
